def main() -> None:
    print("Hello from vibe-coding!")
